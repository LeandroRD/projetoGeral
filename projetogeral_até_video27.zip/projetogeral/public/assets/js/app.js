/* desaparecer a mensagem de erro ligado ao ID*/

$('#error-message').delay(2000).fadeOut('slow');