<?php
	$this->extend('Layout/layout_main')
?>

<?php $this->section('conteudo')?>
	<a href="<?php echo site_url('users')?>"class="btn btn-primary btn-200 mt-5 mp-5">Users</a>
<?php $this->endSection()?>

